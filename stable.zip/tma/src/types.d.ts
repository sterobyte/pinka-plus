declare global {
  interface Window {
    Telegram?: any;
  }
}
export {};
